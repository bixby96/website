+++
# Selected Talks widget.
widget = "talks_selected"
active = false
date = 2016-04-20T00:00:00

title = "Selected Talks"
subtitle = ""

# Order that this section will appear in.
weight = 29

# List format.
#   0 = Simple
#   1 = Detailed
list_format = 0
+++
